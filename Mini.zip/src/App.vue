<template>
  <div>
    <router-link to="/cart">Cart</router-link>
    <router-view/> 
    <!-- <HeaderOne/> -->
    <div class="row section_2 container">
      <div class="col-xxl-3 col-xl-2 col-lg-2 col-md-3 col-sm-1"><ClothesSize/></div>
      <div class="col-xxl-9 col-xl-10 col-lg-10 col-md-9 col-sm-11"><ProductsVue/></div>
    </div>
   
  </div>

</template>

<script>
// import HeaderOne from './components/HeaderOne.vue'
import ClothesSize from './components/ClothesSize.vue'
import ProductsVue from './components/ProductsVue.vue';
export default {
  name: 'App',
  components: {
    // HeaderOne,
    ClothesSize,
    ProductsVue
  }
}
</script>

<style>
  .section_2{
    margin: 50px auto;
  }

  @media screen and (max-width : 767px) {
    
  }
</style>
