<template>
    <nav>
        <div class="cart_qty">
            <img src="../assets/cart_40px.png" alt=""/>
            <span class="badge badge-warning" id="lblCartCount">0</span>
        </div>
    </nav>
</template>
  
<script>

</script>
  
<style>
    nav{
        height: 56px;
        display: flex;
        align-items: center;
        justify-content: flex-end;
    }
    .cart_qty{
        width: 80px;
        height: 56px;
        background-color: black;
        padding: 10px;
    }
    .badge {
        padding-left: 19px;
        padding-right: 19px;
        -webkit-border-radius: 9px;
        -moz-border-radius: 19px;
        border-radius: 19px;
    }
    .label-warning[href],
    .badge-warning[href] {
    background-color: #c67605;
    }
    #lblCartCount {
        font-size: 18px;
        background: #ffb703;
        color: rgb(10, 9, 9);
        padding: 0 12px;
        vertical-align: bottom;
        margin-left: -15px;
    }

    .cart_qty img{
        filter: invert(1);
        cursor: pointer;
    }
    
   
</style>
