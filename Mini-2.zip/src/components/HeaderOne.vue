
  
<style>
nav{
        height: 56px;
        display: flex;
        align-items: center;
        justify-content: flex-end;
    }
    .cart_qty{
        width: 80px;
        height: 56px;
        background-color: black;
        padding: 10px;
    }
    .badge {
        padding-left: 19px;
        padding-right: 19px;
        -webkit-border-radius: 9px;
        -moz-border-radius: 19px;
        border-radius: 19px;
    }
    .label-warning[href],
    .badge-warning[href] {
    background-color: #c67605;
}
#lblCartCount {
    font-size: 18px;
    background: #ffb703;
    color: rgb(10, 9, 9);
    padding: 0 12px;
    vertical-align: bottom;
    margin-left: -15px;
}

.cart_qty img{
        filter: invert(1);
        cursor: pointer;
    }
    
    body {
        font-family: "Lato", sans-serif;
    }
    
    .sidenav {
        height: 100%;
        width: 0;
        position: fixed;
        z-index: 1;
        top: 0;
        right: 0;
        background-color: #111;
        overflow-x: hidden;
        transition: 0.5s;
        padding-top: 60px;
    }
    
    .sidenav a {
        padding: 8px 8px 8px 32px;
        text-decoration: none;
        font-size: 25px;
        color: #818181;
        display: block;
        transition: 0.3s;
    }
    
    .sidenav a:hover {
        color: #f1f1f1;
    }
    
    .sidenav .closebtn {
        position: absolute;
        top: 0;
        right: 25px;
        font-size: 36px;
        margin-left: 50px;
    }
    
    @media screen and (max-height: 450px) {
        .sidenav {padding-top: 15px;}
        .sidenav a {font-size: 18px;}
    }
    
</style>

<template>
    <!-- <nav>
        <div class="cart_qty">
            <img src="../assets/cart_40px.png" alt=""/>
            <span class="badge badge-warning" id="lblCartCount">0</span>
        </div>
    </nav> -->

    <div>
        <div id="mySidenav" class="sidenav">
            <a href="javascript:void(0)" class="closebtn" @click="closeNav">&times;</a>
        </div>
        <div class="cart_qty" @click="openNav">
            <img src="../assets/cart_40px.png" alt=""/>
            <span class="badge badge-warning" id="lblCartCount">0</span>
        </div>
    </div>
</template>
<script setup>
    function openNav() {
        document.getElementById("mySidenav").style.width = "250px";
    }

    function closeNav() {
        document.getElementById("mySidenav").style.width = "0";
    }
</script>