import HeaderOne from '../components/HeaderOne.vue'
import ProductsVue from '../components/ProductsVue.vue'
import { createWebHistory, createRouter } from "vue-router";
// import App from '../App.vue'
const routes = [
    {
        path:"/ProductsVue",
        name : "ProductsVue",
        component : ProductsVue
    },
    {
        path:"/cart",
        name : "HeaderOne",
        component : HeaderOne
    }
]

const router = createRouter({
    history : createWebHistory(),
    routes
})

export default router
