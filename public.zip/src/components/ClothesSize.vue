<template>
    <div class="filter">
        <span class="sizecl"  v-for="(size,idx) in sizes" v-bind:key="idx">{{size}}</span>
    </div>
</template>
  
<script>
  export default{
    name : 'ClothesSize',
    data(){
    return {sizes : ['XS','S','M','L','XL','XXL']
  }}
  }
</script>
  
<style>
    .filter{
        display: flex;
        justify-content: space-evenly;
    }
    .sizecl{
        margin: 10px;
        padding: 10px;
    }
   .sizecl{
        border: 1px solid black;
        border-radius: 50%;
        padding: 12px;
        cursor: pointer;
   }
   
</style>
