<template>
  <div>
    <HeaderOne/>
    <div class="row">
      <div><ClothesSize/></div>
      <div><ProductsVue/></div>
    </div>
  </div>
</template>

<script>
import HeaderOne from './components/HeaderOne.vue'
import ClothesSize from './components/ClothesSize.vue'
import ProductsVue from './components/ProductsVue.vue';
export default {
  name: 'App',
  components: {
    HeaderOne,
    ClothesSize,
    ProductsVue
  }
}
</script>

<style>

</style>
